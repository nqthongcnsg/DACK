

<form action="index.php?controller=discount&action=store" method="post" enctype="multipart/form-data">
					<table class="table">
						
						<tbody>
							<tr>
								<td scope="row"> ID :</td>
								<td><input type="text" name="id"></td>
								
							</tr>
							<tr>
								<td scope="row">Tên Khuyễn Mãi :</td>
								<td><input type="text" name="name"></td>
							
							</tr>
							
						</tbody>
					</table>





					<input type="submit" value="Insert">

				</form>