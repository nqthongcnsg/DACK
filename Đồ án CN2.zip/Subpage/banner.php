<div class="banner">
<div class="container">
<section class="rw-wrapper">
				<h1 class="rw-sentence">
					<span>Thời trang &amp;  Thể thao</span>
					<div class="rw-words rw-words-1">
						<span>Kiểu dáng đẹp</span>
						<span>Quan điểm quyến rũ</span>
						
					
						<span>Năng động</span>
						<span>Cá tính</span>
						<span>Hệ thống thông minh</span>
					</div>
					<div class="rw-words rw-words-2">
						<span>Luôn cập nhật cái phong cách mới</span>
						<span>Nhưng trong một khoảng thời gian nhất định</span>
					
						<span>Là một dân chơi thể thao</span>
						<span>Phù hợp với mọi đối tượng</span>
						<span>Fashion Sport được tạo ra</span>
						
					</div>
				</h1>
			</section>
			</div>
</div>