<div class="content">
			<div class="container">
				<div class="content-top">
					<div class="col-md-6 col-md">
						<div class="col-1">
						 <a href="product.php" class="b-link-stroke b-animate-go  thickbox">
		   <img src="image/trendy.jpg" class="img-responsive2" alt=""/><div class="b-wrapper1 long-img"><p class="b-animate b-from-right    b-delay03 ">Fashion Sport</p><label class="b-animate b-from-right    b-delay03 "></label><h3 class="b-animate b-from-left    b-delay03 ">Thịnh hành</h3></div></a>

							<!---<a href="single.php"><img src="images/pi.jpg" class="img-responsive" alt=""></a>-->
						</div>
						<div class="col-2">
							<span>Ưu đãi lớn</span>
							<h2><a href="product.php">Sang trọng &amp; Hợp thời trang</a></h2>
							<p>Trái với suy nghĩ của nhiều người, Fashion Sport không chỉ đơn giản là văn bản ngẫu nhiên. Nó có nguồn gốc từ một tác phẩm văn học Latinh cổ điển từ năm 45 trước Công nguyên, đã tồn tại hơn 2000 năm</p>
							<a href="product.php" class="buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-6 col-md1">
						<div class="col-3">
							<a href="product.php"><img src="image/forman.jpg" class="img-responsive3" alt="">
							<div class="col-pic">
								<p>Fashion Sport</p>
								<label></label>
								<h5>Cho nam</h5>
							</div></a>
						</div>
						<div class="col-3">
							<a href="product.php"><img src="image/forkid.jpg" class="img-responsive3" alt="">
							<div class="col-pic">
								<p>Fashion Sport</p>
								<label></label>
								<h5>Cho trẻ em</h5>
							</div></a>
						</div>
						<div class="col-3">
							<a href="product.php"><img src="image/forgirls.jpg" class="img-responsive3" alt="">
							<div class="col-pic">
								<p>Fashion Sport</p>
								<label></label>
								<h5>Cho nữ</h5>
							</div></a>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<!--products-->
			<!--start content-mid -->
		    <?php include './Subpage/content_mid.php' ?>
			<!--end content-mid -->
			<!--//products-->
			<!--brand-->
			
			<!--//brand-->
			</div>
			
		</div>