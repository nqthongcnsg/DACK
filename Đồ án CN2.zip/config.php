<?php
define('HOST', 'localhost');
define('DB', 'shop');
define('USER', 'root');
define('PW', '');
